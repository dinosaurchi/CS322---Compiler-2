void fact(int n)
{
	int f;
	//double c;
	//int a[10];
	//float f;
	if(n <= 0)
	{
		return;
	}

	//f = fact(n - 1);
	
	//return "d";
	return;
}

void main()
{
	int m;
	
	//m = fact(10);
}