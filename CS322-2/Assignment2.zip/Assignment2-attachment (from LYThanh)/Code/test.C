
void main() {
	int a;
	a = 2;
	a = (10 + 2) * a;
	a = a - 2;
	printf(a);
}