void main()
{
	int i;
	int f;
	int n;
	f = 1;
	for (i=1; i<=n; i=i+1)
	{
		f = f*i;
	}
	
}
